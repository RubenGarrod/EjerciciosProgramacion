

/**
 *
 * @author AlumnoT
 */
public class Modelo {
    private final String URL = "jdbc:mysql://localhost:3306/tiendaneumaticos?serverTimezone=UTC";
    private final String DBUSER = "root";
    private final String DBPASS = "Dam2324";
    
    public Modelo() {
    }

    /**
     * @return the URL
     */
    public String getURL() {
        return URL;
    }

    /**
     * @return the DBUSER
     */
    public String getDBUSER() {
        return DBUSER;
    }

    /**
     * @return the DBPASS
     */
    public String getDBPASS() {
        return DBPASS;
    }
}

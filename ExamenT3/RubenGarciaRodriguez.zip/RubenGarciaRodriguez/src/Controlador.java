
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 *
 * @author AlumnoT
 */
public class Controlador {
    
    private Connection con;
    private final Modelo model = new Modelo();
    private ResultSet rs;

    public boolean obtenerConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(model.getURL(), model.getDBUSER(), model.getDBPASS());
            return true;
        } catch (Exception e) {
            System.err.println("[ERROR] No se ha podido establecer conexión con la base de datos: " + e.getMessage());
            return false;
        }
    }
    
    public boolean obtenerTabla() {
        try {
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = st.executeQuery("SELECT * FROM pedido");
            return rs != null;
        } catch (SQLException e) {
            System.err.println("[ERROR] No se ha podido obtener los pedidos: " + e.getMessage());
            return false;
        }
    }

    public ResultSet obtenerTablaResultSet() {
        return rs;
    }
    
    
    public boolean insertarDatos(String nombre, String direccion, String tipo, int unidades, double importeTotal, String observaciones) {
        String sql = "INSERT INTO pedido (cliente, direccion, TipoNeumatico, Unidades, ImporteTotal, Observaciones) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(model.getURL(), model.getDBUSER(), model.getDBPASS()); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, direccion);
            pstmt.setString(3, tipo); 
            pstmt.setInt(4, unidades);
            pstmt.setDouble(5, importeTotal);
            pstmt.setString(6, observaciones);
            pstmt.executeUpdate();
            return true;

        } catch (Exception e) {
            return false;
        }
    }

}
